package com.example.snakegame

import android.graphics.Canvas
import android.graphics.Paint
import kotlin.random.Random

class Food {
    var position = generateNewPosition(20, 20)

    fun generateNewPosition(screenWidth: Int, screenHeight: Int): Pair<Int, Int> {
        position = Pair(Random.nextInt(screenWidth), Random.nextInt(screenHeight))
        return position
    }

    fun draw(canvas: Canvas?, paint: Paint, gridSize: Int) {
        canvas?.drawRect(
            position.first * gridSize.toFloat(),
            position.second * gridSize.toFloat(),
            (position.first * gridSize + gridSize).toFloat(),
            (position.second * gridSize + gridSize).toFloat(),
            paint
        )
    }
}
