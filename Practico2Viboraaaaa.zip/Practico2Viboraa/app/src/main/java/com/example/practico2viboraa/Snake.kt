package com.example.practico2viboraa

import android.graphics.Canvas
import android.graphics.Paint

class Snake {
    private val snakeBody = mutableListOf<Pair<Int, Int>>()
    private var direction = Direction.RIGHT

    init {

        snakeBody.add(Pair(10, 10))
        snakeBody.add(Pair(9, 10))
        snakeBody.add(Pair(8, 10))
    }

    fun moveSnake(screenWidth: Int, screenHeight: Int, gridSize: Int) {
        val head = snakeBody[0]
        val newHead = when (direction) {
            Direction.UP -> Pair(head.first, (head.second - 1 + screenHeight) % screenHeight)  // Movimiento circular
            Direction.DOWN -> Pair(head.first, (head.second + 1) % screenHeight)
            Direction.LEFT -> Pair((head.first - 1 + screenWidth) % screenWidth, head.second)
            Direction.RIGHT -> Pair((head.first + 1) % screenWidth, head.second)
        }
        snakeBody.add(0, newHead)
        snakeBody.removeAt(snakeBody.size - 1)
    }

    fun grow() {
        // Añadir un segmento más al final
        snakeBody.add(snakeBody.last())
    }


    fun checkCollision(screenWidth: Int, screenHeight: Int): Boolean {
        val head = snakeBody[0]

        if (snakeBody.drop(1).contains(head)) {
            return true
        }
        return false
    }

    fun checkFood(foodPosition: Pair<Int, Int>): Boolean {
        return snakeBody[0] == foodPosition
    }

    fun changeDirection(newDirection: Direction) {
        // Evitar movimiento en dirección opuesta inmediata
        if ((direction == Direction.UP && newDirection != Direction.DOWN) ||
            (direction == Direction.DOWN && newDirection != Direction.UP) ||
            (direction == Direction.LEFT && newDirection != Direction.RIGHT) ||
            (direction == Direction.RIGHT && newDirection != Direction.LEFT)
        ) {
            direction = newDirection
        }
    }

    fun draw(canvas: Canvas?, paint: Paint, gridSize: Int) {
        for (segment in snakeBody) {
            canvas?.drawRect(
                segment.first * gridSize.toFloat(),
                segment.second * gridSize.toFloat(),
                (segment.first * gridSize + gridSize).toFloat(),
                (segment.second * gridSize + gridSize).toFloat(),
                paint
            )
        }
    }

    enum class Direction {
        UP, DOWN, LEFT, RIGHT
    }
}
