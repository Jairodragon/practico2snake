package com.example.practico2viboraa

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.util.Log
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import com.example.snakegame.Food

class GameView(context: Context, attrs: AttributeSet? = null) : SurfaceView(context, attrs), SurfaceHolder.Callback, Runnable {

    private var thread: Thread? = null
    private var playing = false
    private var canvas: Canvas? = null
    private val paint = Paint()
    private var snake = Snake()
    private var food = Food()
    private val gridSize = 40
    private var screenWidth = 0
    private var screenHeight = 0

    init {
        holder.addCallback(this)
        isFocusable = true
    }

    private fun startGame() {
        Log.d("GameView", "Iniciando juego...")
        snake = Snake()
        food = Food()
        screenWidth = width
        screenHeight = height

        if (screenWidth == 0 || screenHeight == 0) {
            Log.e("GameView", "Error: Dimensiones de pantalla no válidas.")
            return
        }

        playing = true
        thread = Thread(this)
        thread?.start()
    }

    override fun run() {
        while (playing) {
            Log.d("GameView", "Ciclo de juego ejecutándose...")
            update()
            drawGame()
            try {
                Thread.sleep(200)
            } catch (e: InterruptedException) {
                e.printStackTrace()
            }
        }
    }

    private fun update() {
        Log.d("GameView", "Actualizando el estado del juego...")

        if (screenWidth == 0 || screenHeight == 0) {
            Log.e("GameView", "Error: Dimensiones de pantalla no válidas.")
            return
        }

        snake.moveSnake(screenWidth / gridSize, screenHeight / gridSize, gridSize)

        // Si la serpiente come la comida, crece
        if (snake.checkFood(food.position)) {
            snake.grow()
            food.generateNewPosition(screenWidth / gridSize, screenHeight / gridSize)
        }


        if (snake.checkCollision(screenWidth / gridSize, screenHeight / gridSize)) {
            Log.d("GameView", "Colisión detectada, reiniciando juego...")
            restartGame()
        }
    }

    private fun restartGame() {

        snake = Snake()
        food = Food()

    }

    private fun drawGame() {
        if (holder.surface.isValid) {
            canvas = holder.lockCanvas()
            canvas?.drawColor(Color.WHITE)


            paint.color = Color.RED
            food.draw(canvas, paint, gridSize)


            paint.color = Color.BLACK
            snake.draw(canvas, paint, gridSize)

            holder.unlockCanvasAndPost(canvas)

            Log.d("GameView", "Pantalla redibujada...")
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = event.x
        val y = event.y

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                if (y < screenHeight / 4) {
                    snake.changeDirection(Snake.Direction.UP)
                } else if (y > 3 * screenHeight / 4) {
                    snake.changeDirection(Snake.Direction.DOWN)
                } else if (x < screenWidth / 4) {
                    snake.changeDirection(Snake.Direction.LEFT)
                } else if (x > 3 * screenWidth / 4) {
                    snake.changeDirection(Snake.Direction.RIGHT)
                }
            }
        }
        return true
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        startGame()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        screenWidth = width
        screenHeight = height
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        playing = false
        thread?.join()
    }
}
